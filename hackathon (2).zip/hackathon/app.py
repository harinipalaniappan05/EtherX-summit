from flask import Flask, request, jsonify, send_from_directory
import json

app = Flask(__name__)

# Predefined Carbon Footprint values (sample values in kg CO2)
carbon_footprint_data = {
    "groceries": 1.5,
    "fuel": 2.3,
    "flights": 150,
    "electronics": 3.0,
    "transport": 0.5,
    "home_energy": 5.0,
    "water_usage": 0.2
}

# Route to serve the static index.html from the static folder
@app.route('/')
def index():
    print("Serving index.html")
    return send_from_directory('static', 'index.html')

# Route to calculate carbon footprint
@app.route('/calculate', methods=['POST'])
def calculate_footprint():
    data = request.get_json()
    print(f"Received data: {data}")

    total_footprint = 0

    # Process purchases
    if 'purchases' in data:
        for item in data['purchases']:
            category = item['category']
            specific_item = item.get('specificItem', '')  # Get specific item if present
            amount = item['amount']
            print(f"Processing purchase - Category: {category}, Specific Item: {specific_item}, Amount: {amount}")
            
            if category in carbon_footprint_data:
                footprint_for_item = carbon_footprint_data[category] * amount
                print(f"Carbon footprint for {amount} of {category} ({specific_item}): {footprint_for_item} kg CO2")
                total_footprint += footprint_for_item
            else:
                print(f"Category {category} not found in carbon_footprint_data.")

    print(f"Total carbon footprint calculated: {total_footprint} kg CO2")
    
    tips = generate_tips(total_footprint)
    print(f"Generated tips: {tips}")

    # Return the calculated total carbon footprint and tips
    return jsonify({
        'total_footprint': total_footprint,
        'tips': tips
    })

# Function to generate savings tips based on the carbon footprint
def generate_tips(total_footprint):
    tips = []
    if total_footprint > 200:
        tips.append("Your carbon footprint is quite high. Consider significant changes in travel and consumption habits.")
    elif total_footprint > 150:
        tips.append("Try reducing air travel and large electronic purchases to lower your footprint.")
    elif total_footprint > 100:
        tips.append("Reduce frequent flights and explore sustainable fuel alternatives.")
    if total_footprint > 80:
        tips.append("Consider switching to renewable energy sources or carpooling for fuel savings.")
    if total_footprint > 60:
        tips.append("Use more energy-efficient appliances and reduce electricity consumption at home.")
    if total_footprint > 40:
        tips.append("Reduce unnecessary transport use by opting for walking or biking.")
    if total_footprint > 20:
        tips.append("Minimize food waste and buy locally produced groceries to save CO2.")
    if total_footprint <= 20:
        tips.append("You're on the right track! Keep making sustainable choices.")
    if total_footprint < 10:
        tips.append("Great job! Keep making eco-friendly choices and try sharing your tips with others.")
    
    return tips

if __name__ == '__main__':
    print("Starting Flask app...")
    app.run(debug=True)
